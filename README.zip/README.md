LINK arkitektur GrossAreaCalculation README.md
*Created By: Martin Romby Hauge*


# Requirements
## Revit
Revit version: `2019.02`

### Room Parameters
**ParameterName**				**DataType**	**Category**	**Description**
`GrossCalculatedArea` 			Area			Rooms			Used for storring calculation results
`GrossCalculatedAreaDateTime`	String			Rooms			Used for documenting when the GrossArea was updated. Uses DateTime.Now.

## Dynamo pkg
- `Clockwork`
- `LINKarkitektur`
- `spring nodes v.100.0.1`
- `SteamNodes v.1.2.4`

# Rules
## General
- Elements w `Room Bounding = False` are excluded from the calculation.

## Walls
- `Function` parameter is used to determine `Exterior` or `Interior`.

### Interior Walls
- Elements with `Base Offset > 1200mm` are excluded from the calculation.

### Exterior Walls
- Elements are offset in exterior direction with `Width / 2`. Curtain Walls have a `Width = 0`.
- Resulting curves are grouped and trimmed / extended. 

## Columns
- Elements should be of category: `Structural Column`
- Elements can be in `Current.Document` or in `Linked.Document` *

#Creation of Elements of the Categories/ViewTypes; `AreaPlans`, `Area Boundery Lines` & `Areas`.
## AreasPlans
- Area Plans are created with a `AreaScheme` called **Bruttoarealer per rum**. Make sure that the project contains this.
- Area Plans will be created accordingly to the Host `Level` of the calculated `Elements`, ie. `Walls`, `Structural Columns` & `Room Separation Lines`. 
- If a `Level` already has a Area Plan assigned, the existing Area Plan will be kept. New Area Plans will be created for those `Levels` that do not have a Area Plan assigned.

## Area Boundery Lines
- Area Boundery Lines will created based on the calculations and rules applied in section "Rules". 

###Interior Walls
- Area Boundery Lines will created in the center line of the `Element`

###Exterior Walls
- Area Boundery Lines will created on the exterior face of the `Element`

###Structural Columns
- Area Boundery Lines will created in the axis lines of the `Element`

###Room Seperation Lines
- Area Boundery Lines will created with the same underlaying curve as the `Element`

## Areas
 - Element `Area` will be created based on location `x,y,z` of `Room` elements.
 - Areas inherits `Name` and `Number` from the corresponding `Room`

## Rooms
 - `Rooms` will get the Area value from `Areas` transfered to the parameter `GrossCalculatedArea`.
  - Each time the Area is updated a `timestamp (yyyy-mm-dd hh:mm:ss)` will be documented in the parameter `GrossCalculatedAreaDateTime`. 

# Known Issues
- `Columns` will get `Area Boundery Lines` applied in both Axis.
- `Room Seperation Lines` will not extent fully to Exterior Walls. 

# To-do list before calculation
- [ ] Make sure to review Warningslist prior to running this calculation, since  ie. *A wall and a room separation line overlap* will result in AreaBounderies overlapping - creating more warnings. 
- [ ] Set correct value for `Room Boundering`.
- [ ] Set correct value for `Function`.
- [ ] Linked models should have `Room Bounding` set to `True`. 
- [ ] Model has `AreaScheme = Bruttoarealer per rum`.
- [ ] Make sure that the model has the required parameters listed in **Room Parameters** section. 

* *Note that only Structural Models should have `Room Bounding` set to `True`*